﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataGenerator
{
    internal class Course
    {
        public int course_id { get; set; }
        public string name { get; set; }
        public string description { get; set; }
        public string code { get; set; }
        public int design_id { get; set; }
        public int archived { get; set; }

        Random rnd = new Random();

        string GenerateName()
        {
            List<string> Subjects = new List<string> { "Matematika", "Földrajz", "Biológia", "Kémia", "Fizika", "Frontend", "Backend", "Adatbázis Kezelés", "Digitális Kultúra", "Asztali Alk. Fejl.", "Mobil Alk. Fejl.", "Magyar Irodalom", "Magyar Nyelvtan", "Angol Nyelv", "Angol Irodalom", "Szakmai Angol", "Webprogramozás", "Filozófia", "Erkölcstan", "Ének-zene", "Testnevelés", "Történelem", "Állampolgári Ism.", "Digitális Kultúra", "Vizuális Kultúra", "Életivtel és Technika", "Gépészeti Ism.", "Elektronikai Ism.", "Távközlés Alapok", "Finn Nyelv", "Svéd Nyelv", "Norvég Nyelv", "Német Nyelv", "Francia Nyelv", "Olasz Nyelv", "Orosz Nyelv", "Splanyol Nyelv", "Japán Nyelv", "Kínai Nyelv" };
            string classes = "AaBbCcDdEeFfGgHh";
            string separators = "./";

            return Subjects[rnd.Next(Subjects.Count)] + " " + rnd.Next(1, 14) + (rnd.Next(0, 2) == 0 ? "" : separators[rnd.Next(separators.Length)]) + classes[rnd.Next(classes.Length)];
        }

        string GenerateCode()
        {
            string characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
            string code = "";

            for (int i = 0; i < 10; i++)
            {
                code += characters[rnd.Next(characters.Length)];
            }

            return code;
        }

        public void RegenerateCode()
        {
            code = GenerateCode();
        }

        public Course(int id)
        {
            course_id = id;
            name = GenerateName();
            description = name + " online kurzus";
            code = GenerateCode();
            design_id = rnd.Next(1, 7);
            archived = rnd.Next(1, 101) > 95 ? 1 : 0;
        }
    }
}
