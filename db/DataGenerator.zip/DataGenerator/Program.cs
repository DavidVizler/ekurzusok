﻿using System.Globalization;
using System.Text;

namespace DataGenerator
{
    internal class Program
    {
        
        static void Main(string[] args)
        {
            double owner_chance = 5; // Hány % hogy lesz kurzusa
            double student_chance = 99; // Hány % hogy bent lesz kurzusban
            double teacher_chance = 0.5; // Hány % hogy tanár lesz a kurzusban
            int min_courses = 3; // Minimum hány saját kurzusa lesz, ha lesz (min 1)
            int max_courses = 10; // Maximum hány saját kurzusa lesz, ha lesz
            int min_memberships = 1; // Minimum hány kurzusnak tagja (min 1)
            int max_memberships = 20; // Maximum hány kurzusnak tagja
            
            Console.Write("Uj felhasznalok szama : ");
            string? user_count_input = Console.ReadLine();

            if (user_count_input == "") {
                Console.WriteLine("Nincs adatbevitel, kilepes...");
                return;
            }

            if (!int.TryParse(user_count_input, out int user_count)) {
                Console.WriteLine("Hibas adatbevitel, kilepes...");
                return;
            }
            
            // Felhasználók generálása
            List<User> Users = new List<User>();
            for (int i = 1; i < user_count+1; i++)
            {
                Users.Add(new User(i));
            }

            Random rnd = new Random();

            // Kurzusok generálása
            int course_count = 0;
            int membership_count = 0;
            List<Course> Courses = new List<Course>();
            List<Membership> Memberships = new List<Membership>();

            foreach (User user in Users)
            {
                // Lesznek kurzusai a felhasználónak?
                if (rnd.Next(1, Convert.ToInt32(Math.Round(100 / owner_chance))) == 1)
                {
                    // Hány kurzusa lesz a felhasználónak?
                    int user_course_count = rnd.Next(min_courses, max_courses+1);
                    for (int i = 0; i < user_course_count; i++)
                    {
                        Course course = new Course(course_count + 1);

                        // Kurzus kód újragenerálása, ha már létezik
                        while (Courses.Select(x => x.code).Contains(course.code))
                        {
                            course.RegenerateCode();
                        }

                        Courses.Add(course);
                        course_count++;

                        // Tulajdonos hozzáadása
                        Memberships.Add(new Membership(membership_count + 1, user.user_id, course.course_id, 3));
                        membership_count++;
                    }
                }
            }

            // Tagságok generálása
            foreach (User user in Users)
            {                
                // Benne lesz-e valamelyik kurzusban?
                if (rnd.Next(1, Convert.ToInt32(Math.Round(100 / student_chance))) == 1)
                {
                    // Hány kurzusban lesz benne?
                    int user_course_count = rnd.Next(min_memberships, max_memberships+1);

                    for (int i = 0; i < user_course_count; i++)
                    {
                        // Melyik kurzusban lesz benne?
                        int course = rnd.Next(1, course_count+1);

                        // Benne van már?
                        if (!Memberships.Where(x => x.user_id == user.user_id && x.course_id == course).Any())
                        {
                            // Tanár lesz a kurzusban?
                            int role = (rnd.Next(1, Convert.ToInt32(Math.Round(100 / teacher_chance))) == 1) ? 2 : 1;

                            Memberships.Add(new Membership(membership_count + 1, user.user_id, course, role));
                            membership_count++;
                        }
                    }
                }
            }

            // Kiíratás CSV fájlba (hely: DataGenerator/bin/Debug/net8.0)
            using (FileStream users_file = new FileStream("users.csv", FileMode.Create))
            using (StreamWriter user_sw = new StreamWriter(users_file, System.Text.Encoding.UTF8))
            {
                user_sw.WriteLine("user_id;email;firstname;lastname;password");
                foreach (var u in Users)
                {
                    user_sw.WriteLine($"{u.user_id};{u.email};{u.firstname};{u.lastname};{u.password}");
                }
            }

            using (FileStream courses_file = new FileStream("courses.csv", FileMode.Create))
            using (StreamWriter course_sw = new StreamWriter(courses_file, System.Text.Encoding.UTF8))
            {
                course_sw.WriteLine("course_id;name;description;code;design_id;archived");
                foreach (var c in Courses)
                {
                    course_sw.WriteLine($"{c.course_id};{c.name};{c.description};{c.code};{c.design_id};{c.archived}");
                }
            }

            using (FileStream members_file = new FileStream("memberships.csv", FileMode.Create))
            using (StreamWriter member_sw = new StreamWriter(members_file, System.Text.Encoding.UTF8))
            {
                member_sw.WriteLine("membership_id;user_id;course_id;role");
                foreach (var m in Memberships)
                {
                    member_sw.WriteLine($"{m.membership_id};{m.user_id};{m.course_id};{m.role}");
                }
            }

            Console.WriteLine($"{user_count} felhasznalo, {course_count} kurzus es {membership_count} tagsag letrehozva");
        }
    }
}
