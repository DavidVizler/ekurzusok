﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataGenerator
{
    internal class User
    {
        public int user_id { get; set; }
        public string firstname { get; set; }
        public string lastname { get; set; }
        public string email { get; set; }
        public string password { get; set; }

        Random rnd = new Random();

        string RandomFirstName()
        {
            List<string> MaleFirstNames = new List<string> { "Ábel", "Ádám", "Adrián", "Ákos", "Albert", "Alex", "Andor", "András", "Antal", "Ármin", "Arnold", "Áron", "Árpád", "Attila", "Balázs", "Bálint", "Barna", "Barnabás", "Béla", "Bence", "Bendegúz", "Benedek", "Benett", "Benjámin", "Bertalan", "Botond", "Csaba", "Csongor", "Dániel", "Dávid", "Dénes", "Dezső", "Dominik", "Endre", "Erik", "Ernő", "Ervin", "Ferenc", "Gábor", "Gergely", "Gergő", "Géza", "Gusztáv", "György", "Győző", "Gyula", "Hunor", "Imre", "István", "Iván", "János", "Jenő", "József", "Kálmán", "Károly", "Kevin", "Kornél", "Kristóf", "Krisztián", "Krisztofer", "Lajos", "László", "Levente", "Marcell", "Márk", "Martin", "Márton", "Máté", "Mátyás", "Mihály", "Miklós", "Milán", "Nándor", "Nimród", "Noel", "Norbert", "Olivér", "Ottó", "Pál", "Patrik", "Péter", "Richárd", "Róbert", "Roland", "Rudolf", "Sándor", "Soma", "Szabolcs", "Szilárd", "Szilveszter", "Tamás", "Tibor", "Viktor", "Vilmos", "Vince", "Zalán", "Zétény", "Zoltán", "Zsigmond", "Zsolt", "Zsombor" };

            List<string> FemaleFirstNames = new List<string> { "Adrienn", "Ágnes", "Alexandra", "Andrea", "Anett", "Anikó", "Anita", "Anna", "Annamária", "Aranka", "Barbara", "Beáta", "Beatrix", "Bernadett", "Bettina", "Bianka", "Boglárka", "Borbála", "Brigitta", "Csenge", "Csilla", "Diána", "Dóra", "Dorina", "Dorottya", "Edina", "Edit", "Emese", "Emma", "Enikő", "Erika", "Erzséber", "Eszter", "Etelka", "Éva", "Evelin", "Fanni", "Gabriella", "Gizella", "Gréta", "Gyöngyi", "Hajnalka", "Hanna", "Henrietta", "Ibolya", "Ildikó", "Ilona", "Irén", "Izabella", "Jázmin", "Jolán", "Judit", "Júlia", "Julianna", "Katalin", "Kinga", "Kitti", "Klára", "Klaudia", "Krisztina", "Laura", "Lili", "Lilla", "Luca", "Magdolna", "Margit", "Mária", "Marianna", "Márta", "Melinda", "Mónika", "Nikolett", "Nikoletta", "Noémi", "Nóra", "Orsolya", "Petra", "Piroska", "Rebeka", "Regina", "Réka", "Renáta", "Rita", "Róza", "Rozália", "Rózsa", "Sára", "Szilvia", "Terézia", "Tímea", "Tünde", "Valéria", "Veronika", "Viktória", "Virág", "Vivien", "Zita", "Zoé", "Zsanett", "Zsófia", "Zsuzsanna" };

            return rnd.Next(0, 2) == 0 ? MaleFirstNames[rnd.Next(MaleFirstNames.Count)] : FemaleFirstNames[rnd.Next(FemaleFirstNames.Count)];
        }

        string RandomLastName()
        {
            List<string> LastNames = new List<string> { "Antal", "Bakos", "Balázs", "Bálint", "Balla", "Balog", "Balogh", "Barna", "Barta", "Berki", "Bíró", "Bodnár", "Bogdán", "Bognár", "Borbély", "Boros", "Budai", "Csonka", "Deák", "Dudás", "Fábián", "Faragó", "Farkas", "Fazekas", "Fehér", "Fekete", "Fodor", "Fülöp", "Gál", "Gáspár", "Gulyás", "Hajdu", "Halász", "Hegedűs", "Hegedüs", "Horváth", "Illés", "Jakab", "Jónás", "Juhász", "Katona", "Kelemen", "Kerekes", "Király", "Kis", "Kiss", "Kocsis", "Kovács", "Kozma", "Lakatos", "László", "Lengyel", "Lukács", "Magyar", "Major", "Márton", "Máté", "Mészáros", "Mezei", "Molnár", "Nagy", "Nemes", "Németh", "Novák", "Oláh", "Orosz", "Orsós", "Pál", "Papp", "Pásztor", "Pataki", "Péter", "Pintér", "Rácz", "Sándor", "Sárközi", "Simon", "Sipos", "Somogyi", "Soós", "Szabó", "Szalai", "Székely", "Szilágyi", "Szőke", "Szűcs", "Szücs", "Takács", "Tamás", "Tóth", "Török", "Váradi", "Varga", "Vass", "Veres", "Vincze", "Virág", "Vörös" };

            return LastNames[rnd.Next(LastNames.Count)];
        }

        string RemoveAccents(string text)
        {
            return new string(text.Normalize(NormalizationForm.FormD)
                .Where(c => CharUnicodeInfo.GetUnicodeCategory(c) != UnicodeCategory.NonSpacingMark)
                .ToArray()).Normalize(NormalizationForm.FormC)
                .ToLower();
        }

        string GenerateEmail(string firstname, string lastname)
        {
            int email_format = rnd.Next(0, 6);
            string email_name = "";

            switch (email_format)
            {
                case 0:
                    email_name = RemoveAccents(firstname);
                    break;
                case 1:
                    email_name = RemoveAccents(lastname);
                    break;
                case 2:
                    email_name = RemoveAccents(firstname + lastname);
                    break;
                case 3:
                    email_name = RemoveAccents(lastname + firstname);
                    break;
                case 4:
                    email_name = RemoveAccents(firstname + "." + lastname);
                    break;
                case 5:
                    email_name = RemoveAccents(lastname + "." + firstname);
                    break;
                default:
                    break;
            }

            int number_format = rnd.Next(0, 5);
            string email_number = "";

            switch (number_format)
            {
                case 0:
                    email_number = rnd.Next(1, 10000).ToString();
                    break;
                case 1:
                    email_number = rnd.Next(1970, 2020).ToString();
                    break;
                case 2:
                    email_number = rnd.Next(70, 100).ToString();
                    break;
                case 3:
                    email_number = "0" + rnd.Next(0, 10);
                    break;
                default:
                    break;
            }

            return email_name + email_number + "@gemail.kom";
        }

        
        public void RegenerateEmail()
        {
            email = GenerateEmail(firstname, lastname);
        }

        public User(int id)
        {
            user_id = id;
            firstname = RandomFirstName();
            lastname = RandomLastName();
            email = GenerateEmail(firstname, lastname);
            password = "$2y$10$mPo.I8wSPUi.W5QaydbKIeGuR1SyKMPrIXm71XFoJZ7sHQbh/bGjO"; // Almafa123
        }
    }
}
