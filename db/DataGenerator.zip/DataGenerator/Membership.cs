﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataGenerator
{
    internal class Membership
    {
        public int membership_id { get; set; }
        public int user_id { get; set; }
        public int course_id { get; set; }
        public int role { get; set; }

        public Membership(int Id, int User_id, int Course_id, int Role)
        {
            membership_id = Id;
            user_id = User_id;
            course_id = Course_id;
            role = Role;
        }
    }
}
